"""VendorBridge ERP backend application."""
